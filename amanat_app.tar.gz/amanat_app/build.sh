#!/bin/bash

# Script для сборки APK приложения AMANAT
# Использование: ./build.sh [debug|release]

set -e

echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "  🚀 AMANAT APK Builder"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""

# Проверка аргумента
BUILD_TYPE=${1:-debug}

if [ "$BUILD_TYPE" != "debug" ] && [ "$BUILD_TYPE" != "release" ]; then
    echo "❌ Неверный тип сборки. Используйте: debug или release"
    exit 1
fi

echo "📦 Тип сборки: $BUILD_TYPE"
echo ""

# Очистка предыдущих сборок
echo "🧹 Очистка проекта..."
./gradlew clean

# Синхронизация Gradle
echo ""
echo "🔄 Синхронизация Gradle..."
./gradlew sync

# Сборка APK
echo ""
echo "⚙️  Сборка $BUILD_TYPE версии..."
./gradlew assemble${BUILD_TYPE^}

# Получение пути к APK
APK_PATH="app/build/outputs/apk/$BUILD_TYPE/app-$BUILD_TYPE.apk"

echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "✅ Сборка завершена успешно!"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""
echo "📱 APK файл находится по адресу:"
echo "   $APK_PATH"
echo ""
echo "📊 Размер файла:"
ls -lh "$APK_PATH" | awk '{print "   " $5}'
echo ""
echo "💡 Рекомендации:"
echo "   • Установить на устройство: adb install $APK_PATH"
echo "   • Поделиться файлом через: AirDrop, Email, Cloud Drive"
echo "   • Загрузить в Google Play Console"
echo ""
