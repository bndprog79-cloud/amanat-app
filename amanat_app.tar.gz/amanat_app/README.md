# AMANAT - P2P Бюро находок

## Описание проекта

Мобильное приложение для поиска утерянных и возврата найденных вещей, документов и животных между людьми (P2P).

### Главные особенности:
- 🟢 Современный дизайн с зеленой цветовой палитрой
- 🗺️ Интеграция с картами (Google Maps)
- 📸 Загрузка фотографий при создании объявлений
- 💬 Встроенный мессенджер для общения
- 🛡️ Защита от мошенников
- 🇰🇿 Казахский язык интерфейса
- 📱 Поддержка iOS и Android

## Требования к разработке

### Инструменты:
- **Android Studio** (версия 2023.1 или выше)
- **Java Development Kit (JDK)** 11 или выше
- **Gradle** 8.0+
- **Android SDK** (API Level 34, минимум API 24)
- **Git** для контроля версий

### Установка:

1. **Скачать Android Studio:**
   https://developer.android.com/studio

2. **Установить Android SDK:**
   - Запустить Android Studio
   - Перейти в SDK Manager
   - Установить: Android SDK 34, Android SDK Tools, Google Play Services

3. **Установить Git:**
   https://git-scm.com/

## Структура проекта

```
amanat_app/
├── app/
│   ├── src/
│   │   ├── main/
│   │   │   ├── java/com/amanat/
│   │   │   │   ├── ui/
│   │   │   │   │   ├── screens/     # Экраны приложения
│   │   │   │   │   └── theme/       # Тема и стили
│   │   │   │   ├── viewmodel/       # ViewModel для управления состоянием
│   │   │   │   ├── model/           # Модели данных
│   │   │   │   ├── repository/      # Работа с данными
│   │   │   │   └── utils/           # Утилиты
│   │   │   ├── res/
│   │   │   │   ├── layout/          # XML макеты (для старого подхода)
│   │   │   │   ├── drawable/        # Иконки и графика
│   │   │   │   ├── values/          # Ресурсы (строки, цвета)
│   │   │   │   └── values-kk/       # Казахский язык
│   │   │   └── AndroidManifest.xml
│   │   ├── test/                    # Unit тесты
│   │   └── androidTest/             # UI тесты
│   ├── build.gradle.kts
│   └── proguard-rules.pro
├── build.gradle.kts
├── settings.gradle.kts
└── gradle/

```

## Сборка APK

### Способ 1: Через Android Studio (Рекомендуется)

1. **Открыть проект:**
   - Запустить Android Studio
   - File → Open → выбрать папку `amanat_app`

2. **Синхронизировать Gradle:**
   - File → Sync Now
   - Дождаться завершения синхронизации

3. **Собрать APK (Release версия):**
   - Build → Build Bundle(s) / APK(s) → Build APK(s)
   - Дождаться завершения сборки

4. **Найти готовый APK:**
   ```
   amanat_app/app/build/outputs/apk/release/app-release.apk
   ```

### Способ 2: Через командную строку (Gradle)

1. **Перейти в папку проекта:**
   ```bash
   cd amanat_app
   ```

2. **Собрать Debug версию (быстрее):**
   ```bash
   ./gradlew assembleDebug
   ```
   APK будет в: `app/build/outputs/apk/debug/app-debug.apk`

3. **Собрать Release версию (для публикации):**
   ```bash
   ./gradlew assembleRelease
   ```
   APK будет в: `app/build/outputs/apk/release/app-release.apk`

4. **Собрать подписанный APK (для Google Play):**
   ```bash
   ./gradlew bundleRelease
   ```

## Конфигурация перед сборкой

### 1. Google Maps API Key

Получить Google Maps API Key:
- Перейти на https://console.cloud.google.com
- Создать новый проект
- Включить Google Maps API
- Создать API Key
- Добавить в `AndroidManifest.xml`:

```xml
<meta-data
    android:name="com.google.android.geo.API_KEY"
    android:value="YOUR_GOOGLE_MAPS_API_KEY" />
```

### 2. Firebase (опционально, для Push-уведомлений)

1. Перейти на https://firebase.google.com/
2. Создать проект
3. Добавить Android приложение
4. Скачать `google-services.json`
5. Поместить файл в `app/` папку

### 3. Подписание APK для Google Play

Создать keystore:
```bash
keytool -genkey -v -keystore my-release-key.keystore \
  -keyalg RSA -keysize 2048 -validity 10000 -alias my-key-alias
```

Добавить в `app/build.gradle.kts`:
```kotlin
signingConfigs {
    create("release") {
        storeFile = file("my-release-key.keystore")
        storePassword = "your_store_password"
        keyAlias = "my-key-alias"
        keyPassword = "your_key_password"
    }
}
```

## Тестирование

### Запуск на эмуляторе:
```bash
./gradlew installDebug
```

### Запуск Unit тестов:
```bash
./gradlew test
```

### Запуск UI тестов:
```bash
./gradlew connectedAndroidTest
```

## Основные компоненты приложения

### Экраны (Screens)
- **LoginScreen** - Вход и регистрация
- **MainScreen** - Главная лента объявлений
- **CreateAnnouncementScreen** - Создание объявления
- **AnnouncementDetailScreen** - Детали объявления
- **ChatScreen** - Мессенджер
- **ProfileScreen** - Профиль пользователя
- **MapScreen** - Карта с объявлениями

### Модели (Models)
- `Announcement` - Объявление о находке/потере
- `User` - Профиль пользователя
- `Message` - Сообщение в чате
- `Report` - Жалоба на пользователя/объявление

### ViewModel
- `AmanatViewModel` - Управление состоянием приложения

## Публикация в Google Play

1. Подготовить подписанный APK (см. выше)
2. Перейти в Google Play Console (https://play.google.com/console)
3. Создать новое приложение
4. Загрузить APK на вкладке "Релиз"
5. Заполнить описание, скриншоты, рейтинги
6. Подать на проверку

## Поддерживаемые версии Android

- **Минимальная:** Android 7.0 (API 24)
- **Целевая:** Android 14 (API 34)
- **Рекомендуемая:** Android 12+ (API 31+)

## Размер приложения

- **Debug версия:** ~50-80 MB
- **Release версия (подписанная):** ~25-35 MB

## Возможные проблемы и решения

### Проблема: "Gradle sync failed"
**Решение:** 
```bash
./gradlew clean
./gradlew build --refresh-dependencies
```

### Проблема: "API Key is missing"
**Решение:** Добавьте Google Maps API Key в AndroidManifest.xml

### Проблема: "Compilation failed"
**Решение:** Убедитесь, что установлены все зависимости:
```bash
./gradlew build --scan
```

### Проблема: "Out of memory during build"
**Решение:** Увеличьте heap size в `gradle.properties`:
```
org.gradle.jvmargs=-Xmx2048m
```

## Зависимости

- **AndroidX Core:** 1.12.0
- **Jetpack Compose:** 1.5.4
- **Material3:** 1.1.1
- **Retrofit:** 2.9.0
- **Room Database:** 2.5.2
- **Google Play Services:** Maps, Location

## Лицензия

Проект AMANAT 2024. Все права защищены.

## Контакты

- Email: support@amanat.kz
- Phone: +7 (7292) XXX-XX-XX
- Web: https://amanat.kz

## Дополнительные ресурсы

- [Android Developer Documentation](https://developer.android.com/docs)
- [Jetpack Compose Guide](https://developer.android.com/jetpack/compose)
- [Material Design 3](https://m3.material.io/)
- [Google Maps API](https://developers.google.com/maps)

---

**Версия:** 1.0.0  
**Последнее обновление:** May 2026
