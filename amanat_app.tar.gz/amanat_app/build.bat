@echo off
REM Script для сборки APK приложения AMANAT (Windows)
REM Использование: build.bat [debug|release]

setlocal enabledelayedexpansion

echo.
echo ===============================================================
echo   AMANAT APK Builder (Windows)
echo ===============================================================
echo.

REM Проверка аргумента
set BUILD_TYPE=%1
if "%BUILD_TYPE%"=="" set BUILD_TYPE=debug

if /I not "%BUILD_TYPE%"=="debug" if /I not "%BUILD_TYPE%"=="release" (
    echo ERROR: Неверный тип сборки. Используйте: debug или release
    exit /b 1
)

echo Package Type: %BUILD_TYPE%
echo.

REM Очистка предыдущих сборок
echo Очистка проекта...
call gradlew.bat clean
if errorlevel 1 goto error

REM Синхронизация Gradle
echo.
echo Синхронизация Gradle...
call gradlew.bat sync
if errorlevel 1 goto error

REM Сборка APK
echo.
echo Сборка %BUILD_TYPE% версии...

if /I "%BUILD_TYPE%"=="debug" (
    call gradlew.bat assembleDebug
) else (
    call gradlew.bat assembleRelease
)

if errorlevel 1 goto error

echo.
echo ===============================================================
echo Сборка завершена успешно!
echo ===============================================================
echo.
echo APK файл находится по адресу:
echo    app\build\outputs\apk\%BUILD_TYPE%\app-%BUILD_TYPE%.apk
echo.
echo Для установки на устройство используйте:
echo    adb install app\build\outputs\apk\%BUILD_TYPE%\app-%BUILD_TYPE%.apk
echo.
goto end

:error
echo.
echo ERROR: Сборка не удалась!
echo.
pause
exit /b 1

:end
pause
