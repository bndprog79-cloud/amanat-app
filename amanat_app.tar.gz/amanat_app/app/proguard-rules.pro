# This is a configuration file for ProGuard.
# http://proguard.sourceforge.net/index.html#manual/usage.html

-dontusemixedcaseclassnames

# Сохраняем линии номеров для логирования
-keepattributes SourceFile,LineNumberTable
-renamesourcefileattribute SourceFile

# Сохраняем перечисления
-keepclassmembers enum * {
    public static **[] values();
    public static ** valueOf(java.lang.String);
}

# Сохраняем Parcelable классы
-keep class * implements android.os.Parcelable {
    public static final android.os.Parcelable$Creator *;
}

# Сохраняем классы моделей
-keep class com.amanat.model.** { *; }

# Сохраняем ViewModel
-keep class com.amanat.viewmodel.** { *; }

# Сохраняем Retrofit сервисы
-keepclasseswithmembernames class * {
    @retrofit2.http.* <methods>;
}

# Google Play Services
-keep class com.google.android.gms.** { *; }
-dontwarn com.google.android.gms.**
