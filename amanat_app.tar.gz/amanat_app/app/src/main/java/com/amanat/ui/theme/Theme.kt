package com.amanat.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

// Основные цвета для AMANAT
val PrimaryGreen = Color(0xFF2D7A3E)      // Изумрудный зеленый
val SecondaryMint = Color(0xFF7CCA5F)     // Мятный зеленый
val TertiaryGreen = Color(0xFFC8E6C9)     // Светлый зеленый
val BackgroundLight = Color(0xFFFFFFFF)   // Белый
val BackgroundDark = Color(0xFF1A1A1A)    // Темно-серый
val SurfaceGray = Color(0xFFF5F5F5)       // Светло-серый
val ErrorRed = Color(0xFFD32F2F)          // Красный для ошибок
val WarningYellow = Color(0xFFFFA500)     // Оранжевый для предупреждений

val LightColorScheme = lightColorScheme(
    primary = PrimaryGreen,
    secondary = SecondaryMint,
    tertiary = TertiaryGreen,
    background = BackgroundLight,
    surface = SurfaceGray,
    error = ErrorRed,
    onPrimary = Color.White,
    onSecondary = Color.White,
    onTertiary = Color.Black,
    onBackground = Color.Black,
    onSurface = Color.Black,
    onError = Color.White
)

val DarkColorScheme = darkColorScheme(
    primary = SecondaryMint,
    secondary = PrimaryGreen,
    tertiary = TertiaryGreen,
    background = BackgroundDark,
    surface = Color(0xFF2D2D2D),
    error = ErrorRed,
    onPrimary = Color.Black,
    onSecondary = Color.White,
    onTertiary = Color.Black,
    onBackground = Color.White,
    onSurface = Color.White,
    onError = Color.White
)

@Composable
fun AmanatTheme(
    darkTheme: Boolean = false,
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = AmanatTypography,
        content = content
    )
}
