package com.amanat.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.amanat.model.AnnouncementType
import com.amanat.ui.theme.PrimaryGreen
import com.amanat.ui.theme.SecondaryMint
import com.amanat.viewmodel.AmanatViewModel

@Composable
fun MainScreen(viewModel: AmanatViewModel = viewModel()) {
    val selectedTab by viewModel.selectedTab.collectAsState()
    val announcements by viewModel.announcements.collectAsState()
    val isMapView by viewModel.isMapView.collectAsState()
    val currentUser by viewModel.currentUser.collectAsState()

    LaunchedEffect(Unit) {
        viewModel.loadAnnouncements()
    }

    if (currentUser == null) {
        LoginScreen(viewModel)
    } else {
        Scaffold(
            bottomBar = {
                BottomNavigationBar(
                    onCreateAnnouncement = { /* Open create screen */ }
                )
            }
        ) { paddingValues ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues)
                    .background(MaterialTheme.colorScheme.background)
            ) {
                // Табы "Потеряли" и "Нашли"
                TabRow(
                    selectedTabIndex = if (selectedTab == AnnouncementType.FOUND) 0 else 1,
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(MaterialTheme.colorScheme.background),
                    indicator = { tabPositions ->
                        TabRowDefaults.Indicator(
                            Modifier.tabIndicatorOffset(tabPositions[if (selectedTab == AnnouncementType.FOUND) 0 else 1]),
                            height = 4.dp,
                            color = PrimaryGreen
                        )
                    }
                ) {
                    Tab(
                        selected = selectedTab == AnnouncementType.FOUND,
                        onClick = { viewModel.setSelectedTab(AnnouncementType.FOUND) },
                        text = {
                            Text(
                                "Табылды",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    )
                    Tab(
                        selected = selectedTab == AnnouncementType.LOST,
                        onClick = { viewModel.setSelectedTab(AnnouncementType.LOST) },
                        text = {
                            Text(
                                "Жоғалады",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    )
                }

                // Фильтры и переключатель вида
                FilterBar(
                    isMapView = isMapView,
                    onToggleView = { viewModel.toggleMapView() }
                )

                // Список объявлений
                if (!isMapView) {
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(8.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        items(announcements) { announcement ->
                            AnnouncementCard(announcement)
                        }
                    }
                } else {
                    MapView()
                }
            }
        }
    }
}

@Composable
fun TabRow(
    selectedTabIndex: Int,
    modifier: Modifier = Modifier,
    indicator: @Composable (List<TabPosition>) -> Unit = @Composable { tabPositions ->
        if (selectedTabIndex < tabPositions.size) {
            TabRowDefaults.Indicator(
                Modifier
                    .tabIndicatorOffset(tabPositions[selectedTabIndex])
            )
        }
    },
    content: @Composable () -> Unit
) {
    Surface(
        modifier = modifier.then(Modifier.height(56.dp)),
        color = MaterialTheme.colorScheme.surface,
        contentColor = MaterialTheme.colorScheme.onSurface
    ) {
        Row(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background),
            horizontalArrangement = Arrangement.spacedBy(0.dp)
        ) {
            content()
        }
        indicator(emptyList())
    }
}

@Composable
fun FilterBar(
    isMapView: Boolean,
    onToggleView: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(12.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Button(
            onClick = onToggleView,
            modifier = Modifier.wrapContentSize(),
            colors = ButtonDefaults.buttonColors(
                containerColor = if (isMapView) PrimaryGreen else MaterialTheme.colorScheme.surface
            )
        ) {
            Icon(
                imageVector = if (isMapView) Icons.Filled.Map else Icons.Filled.List,
                contentDescription = null,
                modifier = Modifier.size(20.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(if (isMapView) "Карта" else "Тізім")
        }

        Button(
            onClick = { /* Filter */ },
            modifier = Modifier.wrapContentSize(),
            colors = ButtonDefaults.buttonColors(
                containerColor = MaterialTheme.colorScheme.surface
            )
        ) {
            Icon(
                imageVector = Icons.Filled.FilterList,
                contentDescription = null,
                modifier = Modifier.size(20.dp)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text("Фильтр")
        }
    }
}

@Composable
fun AnnouncementCard(announcement: com.amanat.model.Announcement) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .wrapContentHeight(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = announcement.title,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = announcement.city,
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                    )
                }
                Surface(
                    modifier = Modifier
                        .background(
                            color = if (announcement.type == AnnouncementType.FOUND) 
                                SecondaryMint else PrimaryGreen,
                            shape = RoundedCornerShape(8.dp)
                        )
                        .padding(4.dp)
                ) {
                    Text(
                        text = if (announcement.type == AnnouncementType.FOUND) "Табылды" else "Жоғалады",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onPrimary,
                        modifier = Modifier.padding(4.dp)
                    )
                }
            }

            Text(
                text = announcement.description,
                fontSize = 14.sp,
                maxLines = 2
            )

            if (announcement.reward.isNotEmpty()) {
                Text(
                    text = "Сыйлық: ${announcement.reward}",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = PrimaryGreen
                )
            }

            Button(
                onClick = { /* Open details */ },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(36.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = PrimaryGreen
                ),
                shape = RoundedCornerShape(8.dp)
            ) {
                Text("Көбірек білу", fontSize = 12.sp)
            }
        }
    }
}

@Composable
fun MapView() {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background),
        contentAlignment = Alignment.Center
    ) {
        Text(
            "Карта (Google Maps интеграциясы)",
            fontSize = 14.sp,
            color = MaterialTheme.colorScheme.onBackground
        )
    }
}

@Composable
fun BottomNavigationBar(
    onCreateAnnouncement: () -> Unit
) {
    BottomAppBar(
        modifier = Modifier.fillMaxWidth(),
        containerColor = MaterialTheme.colorScheme.surface,
        contentColor = MaterialTheme.colorScheme.onSurface
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(56.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = { /* Home */ }) {
                Icon(Icons.Filled.Home, contentDescription = "Басты бет")
            }
            IconButton(onClick = { /* Messages */ }) {
                Icon(Icons.Filled.Mail, contentDescription = "Хабарламалар")
            }
            FloatingActionButton(
                onClick = onCreateAnnouncement,
                modifier = Modifier.size(56.dp),
                containerColor = SecondaryMint,
                shape = RoundedCornerShape(28.dp)
            ) {
                Icon(
                    Icons.Filled.Add,
                    contentDescription = "Құлын өндіру",
                    tint = MaterialTheme.colorScheme.onPrimary,
                    modifier = Modifier.size(28.dp)
                )
            }
            IconButton(onClick = { /* Favorites */ }) {
                Icon(Icons.Filled.Favorite, contentDescription = "Таңдаулылар")
            }
            IconButton(onClick = { /* Profile */ }) {
                Icon(Icons.Filled.AccountCircle, contentDescription = "Профиль")
            }
        }
    }
}
