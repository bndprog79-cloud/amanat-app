package com.amanat.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.amanat.model.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

class AmanatViewModel : ViewModel() {

    // Состояния UI
    private val _announcements = MutableStateFlow<List<Announcement>>(emptyList())
    val announcements: StateFlow<List<Announcement>> = _announcements

    private val _currentUser = MutableStateFlow<User?>(null)
    val currentUser: StateFlow<User?> = _currentUser

    private val _selectedTab = MutableStateFlow(AnnouncementType.FOUND)
    val selectedTab: StateFlow<AnnouncementType> = _selectedTab

    private val _filterCategory = MutableStateFlow<Category?>(null)
    val filterCategory: StateFlow<Category?> = _filterCategory

    private val _isMapView = MutableStateFlow(false)
    val isMapView: StateFlow<Boolean> = _isMapView

    private val _userLocation = MutableStateFlow<Pair<Double, Double>?>(null)
    val userLocation: StateFlow<Pair<Double, Double>?> = _userLocation

    private val _radiusFilter = MutableStateFlow(5) // км
    val radiusFilter: StateFlow<Int> = _radiusFilter

    private val _messages = MutableStateFlow<List<Message>>(emptyList())
    val messages: StateFlow<List<Message>> = _messages

    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading

    // Функции
    fun setSelectedTab(type: AnnouncementType) {
        _selectedTab.value = type
        loadAnnouncements()
    }

    fun toggleMapView() {
        _isMapView.value = !_isMapView.value
    }

    fun setFilterCategory(category: Category?) {
        _filterCategory.value = category
        loadAnnouncements()
    }

    fun setRadiusFilter(radius: Int) {
        _radiusFilter.value = radius
        loadAnnouncements()
    }

    fun setUserLocation(latitude: Double, longitude: Double) {
        _userLocation.value = Pair(latitude, longitude)
        loadAnnouncements()
    }

    fun loadAnnouncements() {
        viewModelScope.launch {
            _isLoading.value = true
            try {
                // Симуляция загрузки данных
                val mockAnnouncements = generateMockAnnouncements()
                val filtered = mockAnnouncements
                    .filter { it.type == _selectedTab.value }
                    .filter { _filterCategory.value == null || it.category == _filterCategory.value }
                
                _announcements.value = filtered
            } finally {
                _isLoading.value = false
            }
        }
    }

    fun loginUser(phoneNumber: String, password: String) {
        viewModelScope.launch {
            _isLoading.value = true
            try {
                // Симуляция входа
                val user = User(
                    id = "user_${System.currentTimeMillis()}",
                    name = "Иван",
                    nickname = "ivan_user",
                    phoneNumber = phoneNumber,
                    city = "Шымкент"
                )
                _currentUser.value = user
            } finally {
                _isLoading.value = false
            }
        }
    }

    fun createAnnouncement(announcement: Announcement) {
        viewModelScope.launch {
            _isLoading.value = true
            try {
                val newAnnouncement = announcement.copy(
                    id = "ann_${System.currentTimeMillis()}",
                    userId = _currentUser.value?.id ?: "",
                    createdAt = System.currentTimeMillis()
                )
                _announcements.value = _announcements.value + newAnnouncement
            } finally {
                _isLoading.value = false
            }
        }
    }

    fun archiveAnnouncement(announcementId: String) {
        viewModelScope.launch {
            _announcements.value = _announcements.value.map { ann ->
                if (ann.id == announcementId) ann.copy(isArchived = true) else ann
            }
        }
    }

    fun sendMessage(message: Message) {
        viewModelScope.launch {
            _messages.value = _messages.value + message
        }
    }

    fun reportAnnouncement(report: Report) {
        viewModelScope.launch {
            // Отправка жалобы на сервер
        }
    }

    private fun generateMockAnnouncements(): List<Announcement> {
        return listOf(
            Announcement(
                id = "1",
                type = AnnouncementType.FOUND,
                category = Category.DOCUMENTS,
                title = "Паспорт найден",
                description = "Найден паспорт на ул. Абая, 100",
                latitude = 42.3006,
                longitude = 69.5964,
                city = "Шымкент"
            ),
            Announcement(
                id = "2",
                type = AnnouncementType.FOUND,
                category = Category.SMARTPHONES,
                title = "iPhone найден",
                description = "Черный iPhone 13 найден в метро",
                latitude = 42.3050,
                longitude = 69.5980,
                city = "Шымкент"
            ),
            Announcement(
                id = "3",
                type = AnnouncementType.LOST,
                category = Category.DOGS,
                title = "Потеряна собака",
                description = "Потеряна белая овчарка, зовут Макс",
                latitude = 42.2950,
                longitude = 69.5920,
                city = "Шымкент",
                reward = "50000 тг"
            )
        )
    }
}
