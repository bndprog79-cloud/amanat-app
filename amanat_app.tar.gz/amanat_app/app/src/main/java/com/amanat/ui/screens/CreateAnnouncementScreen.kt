package com.amanat.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.PhotoCamera
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.amanat.model.Announcement
import com.amanat.model.AnnouncementType
import com.amanat.model.Category
import com.amanat.model.ContactType
import com.amanat.ui.theme.PrimaryGreen
import com.amanat.ui.theme.SecondaryMint
import com.amanat.viewmodel.AmanatViewModel

@Composable
fun CreateAnnouncementScreen(
    viewModel: AmanatViewModel,
    onBackClick: () -> Unit
) {
    var currentStep by remember { mutableStateOf(1) } // 1: Фото, 2: Категория, 3: Описание, 4: Контакты
    var selectedType by remember { mutableStateOf(AnnouncementType.FOUND) }
    var selectedCategory by remember { mutableStateOf(Category.DOCUMENTS) }
    var title by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var reward by remember { mutableStateOf("") }
    var selectedContactType by remember { mutableStateOf(ContactType.CHAT_ONLY) }
    var photoUrls by remember { mutableStateOf<List<String>>(emptyList()) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // Заголовок с кнопкой возврата
        TopAppBar(
            title = { Text("Құлын өндіру") },
            navigationIcon = {
                IconButton(onClick = onBackClick) {
                    Icon(Icons.Filled.ArrowBack, contentDescription = null)
                }
            },
            colors = TopAppBarDefaults.topAppBarColors(
                containerColor = MaterialTheme.colorScheme.surface
            )
        )

        // Индикатор прогресса
        LinearProgressIndicator(
            progress = (currentStep.toFloat() / 4),
            modifier = Modifier
                .fillMaxWidth()
                .height(2.dp),
            color = PrimaryGreen
        )

        // Содержание в зависимости от шага
        Box(
            modifier = Modifier
                .fillMaxSize()
                .weight(1f)
                .padding(16.dp)
                .verticalScroll(rememberScrollState())
        ) {
            when (currentStep) {
                1 -> PhotoStep(
                    onPhotosSelected = { photoUrls = it },
                    photoUrls = photoUrls
                )
                2 -> CategoryStep(
                    selectedType = selectedType,
                    onTypeChange = { selectedType = it },
                    selectedCategory = selectedCategory,
                    onCategoryChange = { selectedCategory = it }
                )
                3 -> DescriptionStep(
                    title = title,
                    onTitleChange = { title = it },
                    description = description,
                    onDescriptionChange = { description = it },
                    reward = reward,
                    onRewardChange = { reward = it },
                    announcementType = selectedType
                )
                4 -> ContactStep(
                    selectedContactType = selectedContactType,
                    onContactTypeChange = { selectedContactType = it }
                )
            }
        }

        // Кнопки навигации
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            if (currentStep > 1) {
                OutlinedButton(
                    onClick = { currentStep-- },
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text("Артқа")
                }
            }

            Button(
                onClick = {
                    if (currentStep < 4) {
                        currentStep++
                    } else {
                        // Создать объявление
                        val announcement = Announcement(
                            type = selectedType,
                            category = selectedCategory,
                            title = title,
                            description = description,
                            reward = reward,
                            contactType = selectedContactType,
                            photoUrls = photoUrls
                        )
                        viewModel.createAnnouncement(announcement)
                        onBackClick()
                    }
                },
                modifier = Modifier
                    .weight(1f)
                    .height(48.dp),
                colors = ButtonDefaults.buttonColors(containerColor = PrimaryGreen),
                shape = RoundedCornerShape(12.dp)
            ) {
                Text(if (currentStep < 4) "Келесі" else "Жариялау")
            }
        }
    }
}

@Composable
fun PhotoStep(
    onPhotosSelected: (List<String>) -> Unit,
    photoUrls: List<String>
) {
    Column(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            "Қайда суреттері",
            fontSize = 20.sp,
            fontWeight = FontWeight.Bold
        )

        Text(
            "Кемінде 1 сурет қажет",
            fontSize = 14.sp,
            color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f)
        )

        // Сетка с загруженными фото
        for (photo in photoUrls) {
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(200.dp)
                    .background(
                        color = MaterialTheme.colorScheme.surface,
                        shape = RoundedCornerShape(12.dp)
                    ),
                shape = RoundedCornerShape(12.dp)
            ) {
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    Text("Сурет жүктелді")
                }
            }
        }

        // Кнопка добавления фото
        Button(
            onClick = { /* Open camera/gallery */ },
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp),
            colors = ButtonDefaults.buttonColors(containerColor = SecondaryMint),
            shape = RoundedCornerShape(12.dp)
        ) {
            Icon(
                Icons.Filled.PhotoCamera,
                contentDescription = null,
                modifier = Modifier.size(20.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text("Суретті түсіру")
        }
    }
}

@Composable
fun CategoryStep(
    selectedType: AnnouncementType,
    onTypeChange: (AnnouncementType) -> Unit,
    selectedCategory: Category,
    onCategoryChange: (Category) -> Unit
) {
    Column(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            "Нәрсенің түрі",
            fontSize = 20.sp,
            fontWeight = FontWeight.Bold
        )

        // Выбор типа
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    color = MaterialTheme.colorScheme.surface,
                    shape = RoundedCornerShape(12.dp)
                )
                .padding(4.dp),
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Button(
                onClick = { onTypeChange(AnnouncementType.FOUND) },
                modifier = Modifier
                    .weight(1f)
                    .height(40.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (selectedType == AnnouncementType.FOUND) PrimaryGreen 
                    else MaterialTheme.colorScheme.surface
                ),
                shape = RoundedCornerShape(8.dp)
            ) {
                Text("Табылды", fontSize = 12.sp)
            }

            Button(
                onClick = { onTypeChange(AnnouncementType.LOST) },
                modifier = Modifier
                    .weight(1f)
                    .height(40.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (selectedType == AnnouncementType.LOST) PrimaryGreen 
                    else MaterialTheme.colorScheme.surface
                ),
                shape = RoundedCornerShape(8.dp)
            ) {
                Text("Жоғалады", fontSize = 12.sp)
            }
        }

        Text(
            "Санатты таңдау",
            fontSize = 16.sp,
            fontWeight = FontWeight.SemiBold,
            modifier = Modifier.padding(top = 8.dp)
        )

        // Выбор категории (упрощено)
        val categories = listOf(
            Category.DOCUMENTS,
            Category.KEYS,
            Category.SMARTPHONES,
            Category.BAGS,
            Category.DOGS,
            Category.CATS
        )

        categories.forEach { category ->
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(
                        color = if (selectedCategory == category) SecondaryMint.copy(alpha = 0.2f)
                        else MaterialTheme.colorScheme.surface,
                        shape = RoundedCornerShape(8.dp)
                    ),
                shape = RoundedCornerShape(8.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    RadioButton(
                        selected = selectedCategory == category,
                        onClick = { onCategoryChange(category) }
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(getCategoryName(category), fontSize = 14.sp)
                }
            }
        }
    }
}

@Composable
fun DescriptionStep(
    title: String,
    onTitleChange: (String) -> Unit,
    description: String,
    onDescriptionChange: (String) -> Unit,
    reward: String,
    onRewardChange: (String) -> Unit,
    announcementType: AnnouncementType
) {
    Column(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            "Сипаттама",
            fontSize = 20.sp,
            fontWeight = FontWeight.Bold
        )

        OutlinedTextField(
            value = title,
            onValueChange = onTitleChange,
            label = { Text("Тақырыбы") },
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp)
        )

        OutlinedTextField(
            value = description,
            onValueChange = onDescriptionChange,
            label = { Text("Толық сипаттама") },
            modifier = Modifier
                .fillMaxWidth()
                .height(120.dp),
            maxLines = 5,
            shape = RoundedCornerShape(12.dp)
        )

        if (announcementType == AnnouncementType.LOST) {
            OutlinedTextField(
                value = reward,
                onValueChange = onRewardChange,
                label = { Text("Сыйлық (опционалды)") },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp)
            )
        }

        // Предупреждение о безопасности
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    color = MaterialTheme.colorScheme.errorContainer,
                    shape = RoundedCornerShape(12.dp)
                ),
            shape = RoundedCornerShape(12.dp)
        ) {
            Column(
                modifier = Modifier.padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(
                    "⚠️ Ескертпе",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold
                )
                Text(
                    "Ішкі құрылымдарының суретін түсіркуге болмайды! Ербітін өз деректерін растау үшін өтінішу керек.",
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onErrorContainer
                )
            }
        }
    }
}

@Composable
fun ContactStep(
    selectedContactType: ContactType,
    onContactTypeChange: (ContactType) -> Unit
) {
    Column(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            "Байланыс түрі",
            fontSize = 20.sp,
            fontWeight = FontWeight.Bold
        )

        Text(
            "Сіз қалай хабарласыңыз келеді?",
            fontSize = 14.sp,
            color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f)
        )

        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    color = if (selectedContactType == ContactType.CHAT_ONLY) SecondaryMint.copy(alpha = 0.2f)
                    else MaterialTheme.colorScheme.surface,
                    shape = RoundedCornerShape(12.dp)
                ),
            shape = RoundedCornerShape(12.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                RadioButton(
                    selected = selectedContactType == ContactType.CHAT_ONLY,
                    onClick = { onContactTypeChange(ContactType.CHAT_ONLY) }
                )
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text("Тек қана程式 чат", fontWeight = FontWeight.SemiBold)
                    Text("Телефон номеріңіз көрсетілмейді", fontSize = 12.sp, 
                        color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f))
                }
            }
        }

        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    color = if (selectedContactType == ContactType.SHOW_PHONE) SecondaryMint.copy(alpha = 0.2f)
                    else MaterialTheme.colorScheme.surface,
                    shape = RoundedCornerShape(12.dp)
                ),
            shape = RoundedCornerShape(12.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                RadioButton(
                    selected = selectedContactType == ContactType.SHOW_PHONE,
                    onClick = { onContactTypeChange(ContactType.SHOW_PHONE) }
                )
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text("Телефон номеріңіз көрсету", fontWeight = FontWeight.SemiBold)
                    Text("Адам сізге тікелей қоңырау шалуы мүмкін", fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f))
                }
            }
        }
    }
}

fun getCategoryName(category: Category): String {
    return when (category) {
        Category.DOCUMENTS -> "Құжаттар"
        Category.KEYS -> "Кілттер"
        Category.CARDS -> "Карталар"
        Category.PASSES -> "Пропускілер"
        Category.SMARTPHONES -> "Смартфондар"
        Category.HEADPHONES -> "Құлақ теңгешілер"
        Category.LAPTOPS -> "Ноутбуктар"
        Category.SMARTWATCHES -> "Ақылды сағалар"
        Category.CHARGERS -> "Зарядтау құрылғылары"
        Category.BAGS -> "Сомкелер"
        Category.CLOTHING -> "Киім"
        Category.GLASSES -> "Көзілдіктер"
        Category.JEWELRY -> "Зерлер"
        Category.DOGS -> "Иттер"
        Category.CATS -> "Мысықтар"
        Category.OTHER_PETS -> "Басқа ысырықтар"
        Category.STROLLERS -> "Төрт балалар арбасы"
        Category.TOYS -> "Ойыншықтар"
        Category.UMBRELLAS -> "Сауыны"
        Category.SPORTS -> "Спорттық құрал-жабдықтар"
        Category.OTHER -> "Басқасы"
    }
}
