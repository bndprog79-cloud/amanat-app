package com.amanat.model

import java.io.Serializable
import java.util.Date

data class Announcement(
    val id: String = "",
    val userId: String = "",
    val type: AnnouncementType = AnnouncementType.FOUND,
    val category: Category = Category.DOCUMENTS,
    val title: String = "",
    val description: String = "",
    val photoUrls: List<String> = emptyList(),
    val latitude: Double = 0.0,
    val longitude: Double = 0.0,
    val city: String = "",
    val reward: String = "",
    val contactType: ContactType = ContactType.CHAT_ONLY,
    val phoneNumber: String? = null,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val isArchived: Boolean = false,
    val isActive: Boolean = true
) : Serializable

enum class AnnouncementType {
    FOUND, LOST
}

enum class Category {
    // Документы и Ключи
    DOCUMENTS,
    KEYS,
    CARDS,
    PASSES,
    
    // Электроника
    SMARTPHONES,
    HEADPHONES,
    LAPTOPS,
    SMARTWATCHES,
    CHARGERS,
    
    // Личные вещи
    BAGS,
    CLOTHING,
    GLASSES,
    JEWELRY,
    
    // Животные
    DOGS,
    CATS,
    OTHER_PETS,
    
    // Детские товары
    STROLLERS,
    TOYS,
    
    // Предметы быта
    UMBRELLAS,
    SPORTS,
    OTHER
}

enum class ContactType {
    SHOW_PHONE,
    CHAT_ONLY
}

data class User(
    val id: String = "",
    val name: String = "",
    val nickname: String = "",
    val phoneNumber: String = "",
    val city: String = "",
    val registeredAt: Long = System.currentTimeMillis(),
    val rating: Float = 0f,
    val announcements: List<String> = emptyList()
) : Serializable

data class Message(
    val id: String = "",
    val senderId: String = "",
    val recipientId: String = "",
    val announcementId: String = "",
    val text: String = "",
    val timestamp: Long = System.currentTimeMillis(),
    val isRead: Boolean = false
) : Serializable

data class Report(
    val id: String = "",
    val reporterId: String = "",
    val targetId: String = "",
    val announcementId: String = "",
    val reason: ReportReason = ReportReason.FRAUD,
    val description: String = "",
    val timestamp: Long = System.currentTimeMillis()
) : Serializable

enum class ReportReason {
    FRAUD,
    INAPPROPRIATE_CONTENT,
    SPAM,
    FALSE_INFORMATION,
    OTHER
}
