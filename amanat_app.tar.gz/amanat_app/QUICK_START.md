# 🚀 Быстрый старт - AMANAT APK

## За 5 минут до первого APK

### Шаг 1️⃣: Подготовка (2 мин)

#### На Windows:
1. Скачать **Android Studio** (https://developer.android.com/studio)
2. Установить программу
3. При первом запуске выбрать "Standard Installation"
4. Дождаться загрузки SDK (может занять 10-15 минут)

#### На Mac/Linux:
```bash
# Установка через Homebrew (Mac)
brew install --cask android-studio

# Или скачать вручную с developer.android.com
```

---

### Шаг 2️⃣: Открыть проект (1 мин)

1. Запустить **Android Studio**
2. File → Open
3. Выбрать папку `amanat_app`
4. Дождаться индексации файлов (внизу экрана должна исчезнуть прогресс-полоса)

---

### Шаг 3️⃣: Синхронизировать Gradle (1 мин)

В Android Studio должно выскочить уведомление:
```
"Gradle sync required"
```

**Нажать: "Sync Now"**

(Дождаться завершения - может быть 2-3 минуты)

---

### Шаг 4️⃣: Собрать APK (1 мин)

```
Build Menu:
  ↓
Build → Build Bundle(s) / APK(s)
  ↓
Build APK(s)
```

**Дождаться завершения сборки** (обычно 2-5 минут)

---

### 🎉 Готово!

APK файл появится в:
```
amanat_app/app/build/outputs/apk/debug/app-debug.apk
```

---

## Альтернативный способ - Командная строка

Если Android Studio вам не нравится:

### Windows (CMD):
```cmd
cd amanat_app
gradlew.bat assembleDebug
```

### Mac/Linux (Terminal):
```bash
cd amanat_app
./gradlew assembleDebug
```

**Результат** будет в `app/build/outputs/apk/debug/app-debug.apk`

---

## Установка на устройство

### Способ 1: Через Android Studio (Easiest)

1. Подключить телефон (Android) к компьютеру через USB
2. Build → Run 'app'
3. Выбрать устройство
4. Нажать OK

Приложение установится и запустится автоматически! 📱

### Способ 2: Через команду ADB

```bash
adb install app/build/outputs/apk/debug/app-debug.apk
```

### Способ 3: Вручную

1. Скопировать APK файл на телефон
2. Открыть файловый менеджер → найти APK
3. Нажать на файл → "Установить"
4. Подтвердить установку

---

## Тестирование приложения

После установки вы увидите:

```
╔════════════════════════════════════╗
║         AMANAT v1.0.0              ║
║   P2P Табылған нәрселер бюросы    ║
╚════════════════════════════════════╝
```

### Тестовый вход:
- **Телефон:** +7-700-123-45-67
- **Пароль:** 123456

---

## Основные функции в приложении

✅ **Две вкладки:** "Табылды" / "Жоғалады"  
✅ **Переключение вида:** Список / Карта  
✅ **Фильтры:** По категории, дате, радиусу  
✅ **Создание объявления:** 4 простых шага  
✅ **Встроенный чат:** Общение без раскрытия номера  
✅ **Защита от мошенников:** Предупреждения при создании  
✅ **Казахский язык:** Полная локализация

---

## Если что-то не работает

### ❌ Проблема: "Gradle sync failed"

```bash
# Решение:
cd amanat_app
./gradlew clean
./gradlew build --refresh-dependencies
```

### ❌ Проблема: "Compilation failed"

Проверьте:
1. Java установлена: `java -version`
2. Android SDK установлен
3. Internet соединение (для загрузки зависимостей)

### ❌ Проблема: "Out of memory"

Добавить в `gradle.properties`:
```
org.gradle.jvmargs=-Xmx3072m
```

### ❌ Проблема: Устройство не видно ADB

1. Включить режим разработчика на телефоне:
   - Параметры → О телефоне → Нажать 7 раз на "Номер сборки"
2. Параметры → Параметры разработчика → USB отладка (включить)
3. Заново подключить телефон

---

## Следующие шаги для разработки

### Чтобы добавить функции:

1. **Новый экран:**
   ```kotlin
   // Добавить файл в app/src/main/java/com/amanat/ui/screens/
   @Composable
   fun NewScreen() {
       // Ваш UI код здесь
   }
   ```

2. **Новая функция ViewModel:**
   ```kotlin
   // Отредактировать app/src/main/java/com/amanat/viewmodel/AmanatViewModel.kt
   fun myNewFunction() {
       // Ваша логика здесь
   }
   ```

3. **Пересобрать:**
   ```bash
   ./gradlew assembleDebug
   ```

---

## Структура проекта объяснена

```
📦 amanat_app/
│
├── 📄 build.gradle.kts          ← Конфигурация для сборки
├── 📄 settings.gradle.kts       ← Настройки проекта
├── 📄 gradle.properties         ← Свойства Gradle
│
└── 📁 app/                      ← Главное приложение
    │
    ├── 📁 src/main/
    │   ├── 📁 java/com/amanat/
    │   │   ├── 📁 ui/               ← UI компоненты
    │   │   │   ├── screens/         ← Экраны приложения
    │   │   │   └── theme/           ← Цвета, шрифты
    │   │   ├── 📁 viewmodel/        ← Логика приложения
    │   │   ├── 📁 model/            ← Модели данных
    │   │   ├── 📁 repository/       ← Работа с данными
    │   │   └── 📁 utils/            ← Помощники
    │   │
    │   ├── 📁 res/                  ← Ресурсы
    │   │   ├── layout/              ← XML макеты (стари подход)
    │   │   ├── drawable/            ← Иконки, изображения
    │   │   ├── values/              ← Строки, цвета
    │   │   └── values-kk/           ← Казахский язык
    │   │
    │   └── AndroidManifest.xml      ← Конфигурация приложения
    │
    ├── 📁 build/outputs/apk/       ← Готовые APK файлы
    │   ├── debug/
    │   │   └── app-debug.apk        ← Файл для тестирования ✅
    │   └── release/
    │       └── app-release.apk      ← Файл для публикации
    │
    └── build.gradle.kts            ← Конфигурация app-модуля
```

---

## Публикация в Google Play

Когда приложение готово (позже):

1. Подписать APK приватным ключом
2. Перейти на https://play.google.com/console
3. Создать новое приложение
4. Загрузить APK
5. Заполнить описание, скриншоты
6. Отправить на проверку

---

## Полезные ссылки

📚 **Документация:**
- [Android Developer Docs](https://developer.android.com/docs)
- [Jetpack Compose](https://developer.android.com/jetpack/compose)
- [Material Design 3](https://m3.material.io/)

🎓 **Обучение:**
- [Google Codelabs](https://codelabs.developers.google.com/)
- [Android Developers YouTube](https://www.youtube.com/user/androiddevelopers)

🔧 **Инструменты:**
- [Android Studio](https://developer.android.com/studio)
- [Firebase](https://firebase.google.com/)
- [Google Maps API](https://developers.google.com/maps)

---

## ✨ Успехов в разработке!

Если есть вопросы - пишите в поддержку:
- 📧 Email: support@amanat.kz
- 💬 Telegram: @amanat_support
- 🌐 Web: https://amanat.kz

**Happy Coding! 🚀**

---

**Версия:** 1.0.0  
**Последнее обновление:** May 2026
